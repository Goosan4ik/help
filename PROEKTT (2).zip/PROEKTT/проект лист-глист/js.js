document.addEventListener('DOMContentLoaded', function() {
    // Состояние приложения
    const state = {
        currentUser: null,
        boards: [],
        currentBoard: null,
        tasks: [],
        users: []
    };

    // DOM элементы
    const elements = {
        username: document.getElementById('username'),
        loginBtn: document.getElementById('login-btn'),
        registerBtn: document.getElementById('register-btn'),
        logoutBtn: document.getElementById('logout-btn'),
        createBoardBtn: document.getElementById('create-board-btn'),
        boardsContainer: document.getElementById('boards-container'),
        boardDetailsSection: document.getElementById('board-details-section'),
        boardTitle: document.getElementById('board-title'),
        membersList: document.getElementById('members-list'),
        taskColumns: document.getElementById('task-columns'),
        modalOverlay: document.getElementById('modal-overlay'),
        authModal: document.getElementById('auth-modal'),
        authModalTitle: document.getElementById('auth-modal-title'),
        authForm: document.getElementById('auth-form'),
        authError: document.getElementById('auth-error'),
        switchToRegister: document.getElementById('switch-to-register'),
        switchToLogin: document.getElementById('switch-to-login'),
        boardModal: document.getElementById('board-modal'),
        boardModalTitle: document.getElementById('board-modal-title'),
        boardForm: document.getElementById('board-form'),
        taskModal: document.getElementById('task-modal'),
        taskModalTitle: document.getElementById('task-modal-title'),
        taskForm: document.getElementById('task-form'),
        inviteModal: document.getElementById('invite-modal'),
        inviteForm: document.getElementById('invite-form'),
        notifications: document.getElementById('notifications')
    };

    // Инициализация приложения
    function init() {
        // Проверка авторизации (в реальном приложении здесь был бы запрос к серверу)
        const token = localStorage.getItem('token');
        if (token) {
            // В реальном приложении здесь была бы проверка токена
            state.currentUser = { name: 'Тестовый пользователь', email: 'test@example.com' };
            updateAuthUI();
            loadBoards();
        } else {
            updateAuthUI();
        }

        // Навешиваем обработчики событий
        setupEventListeners();
    }

    // Обновление UI в зависимости от авторизации
    function updateAuthUI() {
        if (state.currentUser) {
            elements.username.textContent = state.currentUser.name;
            elements.loginBtn.style.display = 'none';
            elements.registerBtn.style.display = 'none';
            elements.logoutBtn.style.display = 'block';
            elements.createBoardBtn.style.display = 'block';
        } else {
            elements.username.textContent = 'Гость';
            elements.loginBtn.style.display = 'block';
            elements.registerBtn.style.display = 'block';
            elements.logoutBtn.style.display = 'none';
            elements.createBoardBtn.style.display = 'none';
            elements.boardsContainer.innerHTML = '';
            elements.boardDetailsSection.style.display = 'none';
        }
    }

    // Загрузка досок (мок данные)
    function loadBoards() {
        // В реальном приложении здесь был бы запрос к API
        state.boards = [
            { id: 1, name: 'Проект "Веб-сайт"', description: 'Разработка корпоративного сайта', isPublic: true },
            { id: 2, name: 'Маркетинг', description: 'Маркетинговая кампания', isPublic: false },
            { id: 3, name: 'Разработка API', description: 'Бэкенд для мобильного приложения', isPublic: true }
        ];
        
        renderBoards();
    }

    // Отображение досок
    function renderBoards() {
        elements.boardsContainer.innerHTML = '';
        
        state.boards.forEach(board => {
            const boardCard = document.createElement('div');
            boardCard.className = 'board-card';
            boardCard.innerHTML = `
                <h3>${board.name}</h3>
                <p>${board.description}</p>
                <small>${board.isPublic ? 'Публичная' : 'Приватная'}</small>
            `;
            boardCard.addEventListener('click', () => openBoard(board.id));
            elements.boardsContainer.appendChild(boardCard);
        });
    }

    // Открытие доски
    function openBoard(boardId) {
        // В реальном приложении здесь был бы запрос к API
        const board = state.boards.find(b => b.id === boardId);
        if (!board) return;
        
        state.currentBoard = board;
        state.tasks = [
            { id: 1, title: 'Дизайн главной страницы', description: 'Создать макет главной страницы', status: 'new', priority: 'high', deadline: '2023-12-15', assignee: 'user1' },
            { id: 2, title: 'API для авторизации', description: 'Реализовать эндпоинты для регистрации и входа', status: 'in-progress', priority: 'medium', deadline: '2023-12-10', assignee: 'user2' },
            { id: 3, title: 'Тестирование форм', description: 'Протестировать формы обратной связи', status: 'in-review', priority: 'low', deadline: '2023-12-05', assignee: 'user3' },
            { id: 4, title: 'Документация', description: 'Написать документацию для API', status: 'done', priority: 'medium', deadline: '2023-11-30', assignee: 'user1' }
        ];
        
        state.users = [
            { id: 'user1', name: 'Иван Иванов', email: 'ivan@example.com' },
            { id: 'user2', name: 'Петр Петров', email: 'petr@example.com' },
            { id: 'user3', name: 'Мария Сидорова', email: 'maria@example.com' }
        ];
        
        renderBoardDetails();
    }

    // Отображение деталей доски
    function renderBoardDetails() {
        elements.boardTitle.textContent = state.currentBoard.name;
        elements.boardDetailsSection.style.display = 'block';
        
        // Участники
        elements.membersList.innerHTML = '';
        state.users.forEach(user => {
            const memberChip = document.createElement('div');
            memberChip.className = 'member-chip';
            memberChip.textContent = user.name;
            elements.membersList.appendChild(memberChip);
        });
        
        // Задачи
        const statuses = ['new', 'in-progress', 'in-review', 'done'];
        statuses.forEach(status => {
            const column = document.getElementById(`${status}-tasks`);
            if (column) {
                column.innerHTML = '';
                const tasks = state.tasks.filter(task => task.status === status);
                tasks.forEach(task => {
                    const taskCard = createTaskCard(task);
                    column.appendChild(taskCard);
                });
            }
        });
    }

    // Создание карточки задачи
    function createTaskCard(task) {
        const assignee = state.users.find(u => u.id === task.assignee) || { name: 'Не назначено' };
        const priorityClass = `priority-${task.priority}`;
        
        const taskCard = document.createElement('div');
        taskCard.className = 'task-card';
        taskCard.draggable = true;
        taskCard.dataset.taskId = task.id;
        taskCard.innerHTML = `
            <div class="task-priority ${priorityClass}">${getPriorityText(task.priority)}</div>
            <h4>${task.title}</h4>
            <p>${task.description}</p>
            <div class="task-deadline">Срок: ${task.deadline}</div>
            <div class="task-assignee">Исполнитель: ${assignee.name}</div>
        `;
        
        taskCard.addEventListener('click', () => openTaskModal(task.id));
        taskCard.addEventListener('dragstart', handleDragStart);
        
        return taskCard;
    }

    function getPriorityText(priority) {
        const priorities = {
            'low': 'Низкий',
            'medium': 'Средний',
            'high': 'Высокий'
        };
        return priorities[priority] || priority;
    }

    // Drag and Drop
    function handleDragStart(e) {
        e.dataTransfer.setData('text/plain', e.target.dataset.taskId);
    }

    function setupDragAndDrop() {
        const columns = document.querySelectorAll('.tasks-list');
        
        columns.forEach(column => {
            column.addEventListener('dragover', e => {
                e.preventDefault();
                column.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
            });
            
            column.addEventListener('dragleave', () => {
                column.style.backgroundColor = '';
            });
            
            column.addEventListener('drop', e => {
                e.preventDefault();
                column.style.backgroundColor = '';
                
                const taskId = e.dataTransfer.getData('text/plain');
                const newStatus = column.id.split('-')[0];
                
                // В реальном приложении здесь был бы запрос к API
                const task = state.tasks.find(t => t.id === parseInt(taskId));
                if (task) {
                    task.status = newStatus;
                    renderBoardDetails();
                    showNotification(`Задача "${task.title}" перемещена в "${getStatusText(newStatus)}"`);
                }
            });
        });
    }

    function getStatusText(status) {
        const statuses = {
            'new': 'Новые',
            'in-progress': 'В работе',
            'in-review': 'На проверке',
            'done': 'Завершённые'
        };
        return statuses[status] || status;
    }

    // Модальные окна
    function openModal(modal) {
        elements.modalOverlay.style.display = 'block';
        modal.style.display = 'block';
    }

    function closeAllModals() {
        elements.modalOverlay.style.display = 'none';
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
    }

    function openAuthModal(isLogin = true) {
        elements.authModalTitle.textContent = isLogin ? 'Вход' : 'Регистрация';
        elements.authForm.querySelector('button').textContent = isLogin ? 'Войти' : 'Зарегистрироваться';
        elements.switchToRegister.style.display = isLogin ? 'block' : 'none';
        elements.switchToLogin.style.display = isLogin ? 'none' : 'block';
        elements.authError.textContent = '';
        openModal(elements.authModal);
    }

    function openBoardModal(board = null) {
        elements.boardModalTitle.textContent = board ? 'Редактировать доску' : 'Создать новую доску';
        
        if (board) {
            elements.boardForm.elements['board-name'].value = board.name;
            elements.boardForm.elements['board-description'].value = board.description;
            elements.boardForm.elements['board-is-public'].checked = board.isPublic;
        } else {
            elements.boardForm.reset();
        }
        
        openModal(elements.boardModal);
    }

    function openTaskModal(taskId = null) {
        elements.taskModalTitle.textContent = taskId ? 'Редактировать задачу' : 'Новая задача';
        
        // Заполняем список исполнителей
        const assigneeSelect = elements.taskForm.elements['task-assignee'];
        assigneeSelect.innerHTML = '';
        
        state.users.forEach(user => {
            const option = document.createElement('option');
            option.value = user.id;
            option.textContent = user.name;
            assigneeSelect.appendChild(option);
        });
        
        if (taskId) {
            // Редактирование существующей задачи
            const task = state.tasks.find(t => t.id === taskId);
            if (task) {
                elements.taskForm.elements['task-title'].value = task.title;
                elements.taskForm.elements['task-description'].value = task.description;
                elements.taskForm.elements['task-priority'].value = task.priority;
                elements.taskForm.elements['task-deadline'].value = task.deadline;
                elements.taskForm.elements['task-assignee'].value = task.assignee;
                elements.taskForm.elements['task-status'].value = task.status;
            }
        } else {
            // Новая задача
            elements.taskForm.reset();
            const status = document.activeElement.dataset.status;
            elements.taskForm.elements['task-status'].value = status;
        }
        
        openModal(elements.taskModal);
    }

    function openInviteModal() {
        elements.inviteForm.reset();
        openModal(elements.inviteModal);
    }

    // Уведомления
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        elements.notifications.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    // Обработчики событий
    function setupEventListeners() {
        // Кнопки авторизации
        elements.loginBtn.addEventListener('click', () => openAuthModal(true));
        elements.registerBtn.addEventListener('click', () => openAuthModal(false));
        elements.logoutBtn.addEventListener('click', logout);
        
        // Переключение между входом и регистрацией
        elements.switchToRegister.addEventListener('click', () => openAuthModal(false));
        elements.switchToLogin.addEventListener('click', () => openAuthModal(true));
        
        // Кнопки работы с досками
        elements.createBoardBtn.addEventListener('click', () => openBoardModal());
        
        // Закрытие модальных окон
        elements.modalOverlay.addEventListener('click', closeAllModals);
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', closeAllModals);
        });
        
        // Форма авторизации/регистрации
        elements.authForm.addEventListener('submit', handleAuth);
        
        // Форма доски
        elements.boardForm.addEventListener('submit', handleBoardSubmit);
        
        // Форма задачи
        elements.taskForm.addEventListener('submit', handleTaskSubmit);
        
        // Форма приглашения
        elements.inviteForm.addEventListener('submit', handleInviteSubmit);
        
        // Кнопки добавления задач
        document.querySelectorAll('.add-task-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                openTaskModal();
            });
        });
        
        // Drag and Drop
        setupDragAndDrop();
    }

    // Обработчики форм
    function handleAuth(e) {
        e.preventDefault();
        const isLogin = elements.authModalTitle.textContent === 'Вход';
        const email = elements.authForm.elements['auth-email'].value;
        const password = elements.authForm.elements['auth-password'].value;
        
        // В реальном приложении здесь был бы запрос к API
        if (email && password) {
            if (isLogin) {
                // Мок авторизации
                state.currentUser = { name: email.split('@')[0], email };
                localStorage.setItem('token', 'mocked-token');
                updateAuthUI();
                loadBoards();
                closeAllModals();
                showNotification('Вы успешно вошли в систему');
            } else {
                // Мок регистрации
                state.currentUser = { name: email.split('@')[0], email };
                localStorage.setItem('token', 'mocked-token');
                updateAuthUI();
                loadBoards();
                closeAllModals();
                showNotification('Вы успешно зарегистрировались');
            }
        } else {
            elements.authError.textContent = 'Пожалуйста, заполните все поля';
        }
    }

    function logout() {
        localStorage.removeItem('token');
        state.currentUser = null;
        state.boards = [];
        state.currentBoard = null;
        state.tasks = [];
        updateAuthUI();
        showNotification('Вы вышли из системы');
    }

    function handleBoardSubmit(e) {
        e.preventDefault();
        const name = elements.boardForm.elements['board-name'].value;
        const description = elements.boardForm.elements['board-description'].value;
        const isPublic = elements.boardForm.elements['board-is-public'].checked;
        
        if (name) {
            // В реальном приложении здесь был бы запрос к API
            const isEdit = elements.boardModalTitle.textContent.includes('Редактировать');
            
            if (isEdit && state.currentBoard) {
                // Редактирование существующей доски
                state.currentBoard.name = name;
                state.currentBoard.description = description;
                state.currentBoard.isPublic = isPublic;
                showNotification('Доска успешно обновлена');
            } else {
                // Создание новой доски
                const newBoard = {
                    id: Date.now(),
                    name,
                    description,
                    isPublic
                };
                state.boards.push(newBoard);
                showNotification('Доска успешно создана');
            }
            
            renderBoards();
            closeAllModals();
        }
    }

    function handleTaskSubmit(e) {
        e.preventDefault();
        const title = elements.taskForm.elements['task-title'].value;
        const description = elements.taskForm.elements['task-description'].value;
        const priority = elements.taskForm.elements['task-priority'].value;
        const deadline = elements.taskForm.elements['task-deadline'].value;
        const assignee = elements.taskForm.elements['task-assignee'].value;
        const status = elements.taskForm.elements['task-status'].value;
        
        if (title) {
            // В реальном приложении здесь был бы запрос к API
            const isEdit = elements.taskModalTitle.textContent.includes('Редактировать');
            
            if (isEdit) {
                // Редактирование существующей задачи
                const taskId = parseInt(document.activeElement.closest('.task-card')?.dataset.taskId);
                if (taskId) {
                    const task = state.tasks.find(t => t.id === taskId);
                    if (task) {
                        task.title = title;
                        task.description = description;
                        task.priority = priority;
                        task.deadline = deadline;
                        task.assignee = assignee;
                        task.status = status;
                        showNotification('Задача успешно обновлена');
                    }
                }
            } else {
                // Создание новой задачи
                const newTask = {
                    id: Date.now(),
                    title,
                    description,
                    priority,
                    deadline,
                    assignee,
                    status
                };
                state.tasks.push(newTask);
                showNotification('Задача успешно создана');
            }
            
            renderBoardDetails();
            closeAllModals();
        }
    }

    function handleInviteSubmit(e) {
        e.preventDefault();
        const email = elements.inviteForm.elements['invite-email'].value;
        
        if (email) {
            // В реальном приложении здесь был бы запрос к API
            showNotification(`Приглашение отправлено на ${email}`);
            closeAllModals();
        }
    }

    // Запуск приложения
    init();
});
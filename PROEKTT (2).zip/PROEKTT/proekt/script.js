import anime from 'animejs/lib/anime.es.js';

function toggleDropdown() {
  const dropdown = document.querySelector('.drop_menu-container');
  dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// Закрытие меню при клике вне его
document.addEventListener('click', function(event) {
  const dropdown = document.querySelector('.drop_menu-container');
  const button = document.querySelector('.open_profile_button');
  
  if (!button.contains(event.target) && !dropdown.contains(event.target)) {
    dropdown.style.display = 'none';
  }
});

anime({
  targets: '#element1',
  opacity: 0,
  duration: 500,
  complete: function() {
    document.getElementById('element2').style.display = 'block';
    anime({
      targets: '#element2',
      opacity: [0, 1],
      duration: 500
    });
  }
});



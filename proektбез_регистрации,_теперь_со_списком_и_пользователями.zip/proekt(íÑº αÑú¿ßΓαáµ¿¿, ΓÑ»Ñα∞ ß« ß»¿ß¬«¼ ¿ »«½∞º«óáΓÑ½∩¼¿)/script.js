// Директива для закрытия меню при клике вне его
Vue.directive('click-outside', {
  bind: function (el, binding, vnode) {
    el.clickOutsideEvent = function (event) {
      if (!(el === event.target || el.contains(event.target))) {
        vnode.context[binding.expression](event);
      }
    };
    document.body.addEventListener('click', el.clickOutsideEvent);
  },
  unbind: function (el) {
    document.body.removeEventListener('click', el.clickOutsideEvent);
  },
});


new Vue({
  el: '#app',
  data: {
    currentUser: 'Василий',
    userInitial: 'В',
    activeNav: 'home',
    activeView: 'board',
    activeBoard: 1,
    searchQuery: '',

    showColumnMenuForId: null,  // Добавьте это свойство

    // Модальные окна
    showAddBoardModal: false,
    showAddColumnModal: false,
    showAddTaskModal: false,
    showAddMemberModal: false,
    showTaskMenu: false,
    showBoardSelectionModal: false, // Новое свойство для управления модальным окном

    // Позиция контекстного меню
    menuPosition: { x: 0, y: 0 },

    // Выбранные элементы для редактирования
    editingBoard: null,
    editingColumn: null,
    editingTask: null,
    selectedTask: null,
    selectedColumnId: null,
    selectedTaskId: null,

    showBoardMenuForId: null,  // ID доски, для которой открыто меню
    boardMenuPosition: { x: 0, y: 0 },
    showAddBoardModal: false,
    editingBoard: null,

    maxDisplayedMembers: 5, // Максимальное количество отображаемых аватарок
    showAllMembers: false, // Флаг для отображения списка всех пользователей

    // Новые элементы
    newBoard: {
      name: ''
    },
    newColumn: {
      name: ''
    },
    newTask: {
      title: '',
      description: '',
      deadline: '',
      assignee: '',
      columnId: ''
    },
    newMemberEmail: '',

    // Данные приложения
    boards: [
      { id: 1, name: 'Доска 1' },
      { id: 2, name: 'Доска 2' }
    ],
    recentBoards: [
      { id: 1, name: 'Доска 1' },
      { id: 2, name: 'Доска 2' }
    ],
    columns: [
      { id: 1, name: 'Сделать', boardId: 1 },
      { id: 2, name: 'В процессе', boardId: 1 },
      { id: 3, name: 'Завершено', boardId: 1 }
    ],
    tasks: [
      {
        id: 1,
        title: 'Заголовок',
        description: 'Описание',
        deadline: '2025-12-12',
        assignee: 1,
        columnId: 1,
        boardId: 1
      },
      {
        id: 2,
        title: 'Заголовок',
        description: 'Описание',
        deadline: '2025-12-12',
        assignee: 2,
        columnId: 1,
        boardId: 1
      },
      {
        id: 3,
        title: 'Заголовок',
        description: 'Описание',
        deadline: '2025-12-12',
        assignee: 3,
        columnId: 1,
        boardId: 1
      },
      {
        id: 4,
        title: 'Заголовок',
        description: 'Описание',
        deadline: '2025-12-12',
        assignee: 1,
        columnId: 2,
        boardId: 1
      },
      {
        id: 5,
        title: 'Заголовок',
        description: 'Описание',
        deadline: '2025-12-12',
        assignee: 2,
        columnId: 2,
        boardId: 1
      },
      {
        id: 6,
        title: 'Заголовок',
        description: 'Описание',
        deadline: '2025-12-12',
        assignee: 3,
        columnId: 3,
        boardId: 1
      }
    ],
    boardMembers: [
      { id: 1, name: 'Митя', initial: 'М', color: '#FF5858' },
      { id: 2, name: 'Влад', initial: 'В', color: '#59FF4D' },
      { id: 3, name: 'Артем', initial: 'А', color: '#53FFFC' },
      { id: 4, name: 'Василий', initial: 'В', color: '#D95EFF' }
    ]
  },
  computed: {
    filteredTasks() {
      if (!this.searchQuery) return this.tasks;
      const query = this.searchQuery.toLowerCase();

      return this.tasks.filter(task =>
        task.title.toLowerCase().includes(query) ||
        task.description.toLowerCase().includes(query)
      );
    },

    displayedMembers() {
        return this.boardMembers.slice(0, this.maxDisplayedMembers); // Отображаем только первых 5 пользователей
    },
    totalMembers() {
        return this.boardMembers.length; // Общее количество пользователей
    }
  },
  methods: {

  // Открытие модального окна выбора доски
  openBoardSelectionModal() {
    this.showBoardSelectionModal = true;
  },
  // Закрытие модального окна выбора доски
  closeBoardSelectionModal() {
    this.showBoardSelectionModal = false;
  },
  // Выбор доски
  selectBoard(boardId) {
    this.activeBoard = boardId; // Устанавливаем активную доску
    this.closeBoardSelectionModal(); // Закрываем модальное окно
  },
  // Редактирование доски
  editBoard(board) {
    this.editingBoard = board;
    this.newBoard.name = board.name;
    this.showAddBoardModal = true; // Открываем модальное окно редактирования
    this.closeBoardSelectionModal(); // Закрываем окно выбора доски
  },
  // Удаление доски
  deleteBoard(boardId) {
    if (confirm('Вы уверены, что хотите удалить эту доску?')) {
      this.boards = this.boards.filter(b => b.id !== boardId);
      this.recentBoards = this.recentBoards.filter(b => b.id !== boardId);
      if (this.activeBoard === boardId) {
        this.activeBoard = this.boards[0]?.id || null;
      }
    }
  },

    // Работа с досками
    selectBoard(boardId) {
      this.activeBoard = boardId;
    },
    saveBoard() {
      if (this.editingBoard) {
        // Обновляем существующую доску
        const index = this.boards.findIndex(b => b.id === this.editingBoard.id);
        if (index !== -1) {
          this.boards.splice(index, 1, { ...this.editingBoard, name: this.newBoard.name });
        }
      } else {
        // Добавляем новую доску
        const newId = Math.max(...this.boards.map(b => b.id), 0) + 1;
        this.boards.push({
          id: newId,
          name: this.newBoard.name
        });
        this.recentBoards.unshift({
          id: newId,
          name: this.newBoard.name
        });
        if (this.recentBoards.length > 3) {
          this.recentBoards.pop();
        }
      }
      this.resetBoardForm();
      this.showAddBoardModal = false;
    },
    editBoard(board) {
      this.editingBoard = board;
      this.newBoard.name = board.name;
      this.showAddBoardModal = true;
    },
    deleteBoard(boardId) {
      if (confirm('Вы уверены, что хотите удалить эту доску?')) {
        this.boards = this.boards.filter(b => b.id !== boardId);
        this.recentBoards = this.recentBoards.filter(b => b.id !== boardId);
        if (this.activeBoard === boardId) {
          this.activeBoard = this.boards[0]?.id || null;
        }
      }
    },
    resetBoardForm() {
      this.editingBoard = null;
      this.newBoard = { name: '' };
    },


    // Работа с колонками


    // Открытие меню для редактирования и удаления колонки
    openColumnMenu(event, columnId) {
      this.showColumnMenuForId = columnId;
      this.menuPosition = {
        x: event.clientX,
        y: event.clientY
      };
    },
    closeColumnMenu() {
      this.showColumnMenuForId = null;
    },
    editColumn(column) {
      this.editingColumn = column;
      this.newColumn.name = column.name;
      this.showAddColumnModal = true;
      this.closeColumnMenu();
    },
    deleteColumn(columnId) {
      if (confirm('Вы уверены, что хотите удалить эту колонку? Все задачи в ней также будут удалены.')) {
        this.columns = this.columns.filter(c => c.id !== columnId);
        this.tasks = this.tasks.filter(t => t.columnId !== columnId); // Удаляем задачи из удаляемой колонки
      }
      this.closeColumnMenu();
    },



    getColumnsForBoard(boardId) {
      return this.columns.filter(c => c.boardId === boardId);
    },
    openAddColumnModal() {
      this.editingColumn = null;
      this.newColumn = { name: '' };
      this.showAddColumnModal = true;
    },
    editColumn(column) {
      this.editingColumn = column;
      this.newColumn.name = column.name;
      this.showAddColumnModal = true;
    },
    saveColumn() {
      if (this.editingColumn) {
        // Обновляем существующую колонку
        const index = this.columns.findIndex(c => c.id === this.editingColumn.id);
        if (index !== -1) {
          this.columns.splice(index, 1, { ...this.editingColumn, name: this.newColumn.name });
        }
      } else {
        // Добавляем новую колонку
        const newId = Math.max(...this.columns.map(c => c.id), 0) + 1;
        this.columns.push({
          id: newId,
          name: this.newColumn.name,
          boardId: this.activeBoard
        });
      }
      this.resetColumnForm();
      this.showAddColumnModal = false;
    },
    // deleteColumn(columnId) {
    //   if (confirm('Вы уверены, что хотите удалить этот раздел? Все задачи в нем также будут удалены.')) {
    //     this.columns = this.columns.filter(c => c.id !== columnId);
    //     this.tasks = this.tasks.filter(t => t.columnId !== columnId);
    //   }
    // },
    resetColumnForm() {
      this.editingColumn = null;

      this.newColumn = { name: '' };
    },

    // Работа с задачами
    getTasksForColumn(columnId) {
      return this.filteredTasks.filter(t => t.columnId === columnId && t.boardId === this.activeBoard);
    },
    openAddTaskModal(columnId) {
      this.editingTask = null;
      this.newTask = {
        title: '',
        description: '',
        deadline: this.formatDateForInput(new Date()),
        assignee: '',
        columnId: columnId
      };
      this.showAddTaskModal = true;
    },
    selectTask(task) {
      this.selectedTask = task;
      this.editingTask = task;
      this.newTask = { ...task };
      this.showAddTaskModal = true;
    },
    saveTask() {
      if (this.editingTask) {
        // Обновляем существующую задачу
        const index = this.tasks.findIndex(t => t.id === this.editingTask.id);
        if (index !== -1) {
          this.tasks.splice(index, 1, {
            ...this.editingTask,
            title: this.newTask.title,
            description: this.newTask.description,
            deadline: this.newTask.deadline,
            assignee: this.newTask.assignee,
            columnId: this.newTask.columnId
          });
        }
      } else {
        // Добавляем новую задачу
        const newId = Math.max(...this.tasks.map(t => t.id), 0) + 1;
        this.tasks.push({
          id: newId,
          title: this.newTask.title,
          description: this.newTask.description,
          deadline: this.newTask.deadline,
          assignee: this.newTask.assignee,
          columnId: this.newTask.columnId,
          boardId: this.activeBoard
        });
      }
      this.resetTaskForm();
      this.showAddTaskModal = false;
    },
    deleteTask(taskId) {
      if (confirm('Вы уверены, что хотите удалить эту задачу?')) {
        this.tasks = this.tasks.filter(t => t.id !== taskId);
      }
    },
    resetTaskForm() {
      this.editingTask = null;
      this.selectedTask = null;
      this.newTask = {
        title: '',
        description: '',
        deadline: '',
        assignee: '',
        columnId: ''
      };
    },

    // Контекстное меню задач
    openTaskMenu(event, columnId, taskId) {
      console.log('openTaskMenu called', { columnId, taskId, clientX: event.clientX, clientY: event.clientY });
      this.selectedColumnId = columnId;
      this.selectedTaskId = taskId;

      this.menuPosition = {
        x: event.clientX,
        y: event.clientY
      };

      this.showTaskMenu = true;
    },

    closeTaskMenu() {
      this.showTaskMenu = false;
    },
    editSelectedTask() {
      if (this.selectedTaskId) {
        const task = this.tasks.find(t => t.id === this.selectedTaskId);
        if (task) {
          this.selectTask(task);
        }
      }
      this.closeTaskMenu();
    },
    moveTaskToInProgress() {
      if (this.selectedTaskId) {
        const inProgressColumn = this.columns.find(c => c.name === 'В процессе');
        if (inProgressColumn) {
          const taskIndex = this.tasks.findIndex(t => t.id === this.selectedTaskId);
          if (taskIndex !== -1) {

            this.tasks[taskIndex].columnId = inProgressColumn.id;
          }
        }
      }
      this.closeTaskMenu();
    },
    markTaskAsDone() {
      if (this.selectedTaskId) {
        const doneColumn = this.columns.find(c => c.name === 'Завершено');
        if (doneColumn) {
          const taskIndex = this.tasks.findIndex(t => t.id === this.selectedTaskId);
          if (taskIndex !== -1) {
            this.tasks[taskIndex].columnId = doneColumn.id;
          }
        }
      }
      this.closeTaskMenu();
    },
    deleteSelectedTask() {
      if (this.selectedTaskId) {
        this.deleteTask(this.selectedTaskId);
      }
      this.closeTaskMenu();
    },

    // Работа с участниками
    addMember() {
      if (this.newMemberEmail) {
        // В реальном приложении здесь была бы проверка email и запрос к API
        const newId = Math.max(...this.boardMembers.map(m => m.id), 0) + 1;
        const name = this.newMemberEmail.split('@')[0];
        const initial = name.charAt(0).toUpperCase();
        const colors = ['#FF5858', '#59FF4D', '#53FFFC', '#D95EFF', '#FF8A5E', '#5E8AFF'];
        const color = colors[newId % colors.length];

        this.boardMembers.push({
          id: newId,
          name: name,
          initial: initial,
          color: color,
          email: this.newMemberEmail
        });

        this.newMemberEmail = '';
        this.showAddMemberModal = false;
      }
    },
    getMemberColor(memberId) {
      const member = this.boardMembers.find(m => m.id === memberId);
      return member ? member.color : '#888';
    },
    getMemberInitial(memberId) {
      const member = this.boardMembers.find(m => m.id === memberId);
      return member ? member.initial : '?';
    },

    // Вспомогательные методы
    formatDate(dateString) {
      if (!dateString) return '';
      const date = new Date(dateString);
      return date.toLocaleDateString('ru-RU');
    },
    formatDateForInput(date) {
      if (!date) return '';
      const d = new Date(date);
      let month = '' + (d.getMonth() + 1);
      let day = '' + d.getDate();
      const year = d.getFullYear();

      if (month.length < 2) month = '0' + month;
      if (day.length < 2) day = '0' + day;

      return [year, month, day].join('-');
    }
  },
  mounted() {
    // Загружаем данные из localStorage, если они есть
    if (localStorage.getItem('boards')) {
      this.boards = JSON.parse(localStorage.getItem('boards'));
    }
    if (localStorage.getItem('recentBoards')) {
      this.recentBoards = JSON.parse(localStorage.getItem('recentBoards'));
    }
    if (localStorage.getItem('columns')) {
      this.columns = JSON.parse(localStorage.getItem('columns'));
    }
    if (localStorage.getItem('tasks')) {
      this.tasks = JSON.parse(localStorage.getItem('tasks'));
    }
    if (localStorage.getItem('boardMembers')) {
      this.boardMembers = JSON.parse(localStorage.getItem('boardMembers'));
    }
    if (localStorage.getItem('activeBoard')) {
      this.activeBoard = parseInt(localStorage.getItem('activeBoard'));
    }

    // Если нет досок, создаем демо-доску
    if (this.boards.length === 0) {
      this.boards.push({ id: 1, name: 'Моя первая доска' });
      this.recentBoards.push({ id: 1, name: 'Моя первая доска' });
      this.activeBoard = 1;

      this.columns = [
        { id: 1, name: 'Сделать', boardId: 1 },
        { id: 2, name: 'В процессе', boardId: 1 },
        { id: 3, name: 'Завершено', boardId: 1 }
      ];

      this.tasks = [
        {
          id: 1,
          title: 'Пример задачи',
          description: 'Это пример задачи в вашей новой доске',
          deadline: this.formatDateForInput(new Date()),
          assignee: 4,
          columnId: 1,
          boardId: 1
        }
      ];
    }
  },
  watch: {
    // Сохраняем данные в localStorage при изменениях
    boards: {
      handler(newVal) {
        localStorage.setItem('boards', JSON.stringify(newVal));
      },
      deep: true
    },
    recentBoards: {
      handler(newVal) {
        localStorage.setItem('recentBoards', JSON.stringify(newVal));
      },
      deep: true
    },
    columns: {
      handler(newVal) {
        localStorage.setItem('columns', JSON.stringify(newVal));
      },
      deep: true
    },
    tasks: {
      handler(newVal) {
        localStorage.setItem('tasks', JSON.stringify(newVal));
      },
      deep: true
    },
    boardMembers: {
      handler(newVal) {
        localStorage.setItem('boardMembers', JSON.stringify(newVal));
      },
      deep: true
    },
    activeBoard(newVal) {
      localStorage.setItem('activeBoard', newVal.toString());
    }
  }
});